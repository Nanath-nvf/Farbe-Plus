# Registro de execução — compra simulada (CT05)

Data: 17/11/2026. Execução assistida no Microsoft Edge, Windows, em http://127.0.0.1:5180/. Versão exata do Edge e commit do projeto não foram coletados. Responsável pela execução: assistente, a pedido da usuária.

## Pré-condições observadas

Perfil cliente; carrinho vazio; Paracetamol 750mg exibido com preço de R$ 18,50 e 24 unidades de estoque. Usados apenas o endereço fictício e o pagamento Pix simulado oferecidos pela aplicação.

## Passos e resultados observados

1. Abriu o catálogo e buscou Paracetamol: um produto encontrado.
2. Adicionou uma unidade: mensagem de sucesso e indicador do carrinho igual a 1.
3. Abriu o carrinho: uma unidade; subtotal R$ 18,50; frete R$ 7,90; total R$ 26,40.
4. Abriu a finalização: endereço demonstrativo e Pix selecionado.
5. Confirmou o pedido simulado: criado FB-1002 em 17/11/2026, 02:45:58 (horário mostrado pela aplicação), com status Em preparação, uma unidade de Paracetamol e total R$ 26,40.
6. Na tela resultante, o indicador do carrinho voltou a 0.
7. No perfil Administrador > Estoque, Paracetamol 750mg apareceu com 23 unidades (24 antes da compra).

## Conclusão

Compra simulada, total, limpeza do carrinho e redução do estoque: aprovados neste cenário; o estoque passou de 24 para 23 unidades. Não foram testados persistência após recarga, pagamento real, receita, administração ou entrega nesta execução.

Evidências: [captura da confirmação](CT05-compra-simulada.png) e [captura do estoque após a compra](CT05-estoque.png). A data/hora do pedido foi reproduzida da interface; o teste não valida o relógio do computador.

Este registro foi salvo na pasta de entregas do chat. A documentação original em E:\Downloads\farbe-plus\docs não foi atualizada por esta execução.