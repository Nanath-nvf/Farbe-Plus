# CT04 — Carrinho e limite de estoque

- **Data:** 17/11/2026
- **Ambiente:** cópia local demonstrativa em `http://localhost:5180/`, Microsoft Edge; perfil Ana; dados fictícios.
- **Produto:** Paracetamol 750mg; preço unitário exibido R$ 18,50; estoque exibido 24.
- **Resultado observado:** o carrinho chegou a 24 unidades (subtotal R$ 444,00; total com frete R$ 451,90). Um acréscimo adicional não mudou a quantidade, que permaneceu 24. Ao reduzir para 23, subtotal mudou para R$ 425,50 e total para R$ 433,40. Remover o produto deixou o carrinho vazio. Após adicionar novamente uma unidade, “Esvaziar carrinho” também deixou o carrinho vazio.
- **Situação:** aprovado nos comportamentos observados.
- **Evidência:** estado observado diretamente na interface durante a execução; a captura de tela deste cenário não foi exportada como arquivo.
- **Limite:** teste feito na versão demonstrativa local, com uma única linha de produto.
