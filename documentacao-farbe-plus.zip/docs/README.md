# Documentação acadêmica — Farbe+

Revisão documental: 17/11/2026. Base: `src/main.jsx`, `src/style.css`, `package.json`, `package-lock.json`, `index.html` e README da raiz.

O Farbe+ é um protótipo de farmácia virtual em React e Vite. Usa dados fictícios e armazenamento local do navegador. Esta documentação descreve a versão inspecionada; não comprova aprovação acadêmica ou uso em produção.

## Índice

- [Requisitos](requisitos/README.md)
- [Interfaces](interfaces/README.md)
- [Configuração](configuracao/README.md)
- [Scrum](scrum/README.md)
- [UML](uml/README.md)
- [Testes](testes/README.md)
- [Protótipos](prototipos/README.md)
- [Evidências](evidencias/README.md)

## Critério de situação

- **Identificado no código:** há implementação na versão lida; não significa teste funcional aprovado.
- **Planejado/proposto:** sugestão de evolução ou critério de aceite; não implica compromisso da equipe.
- **Testado:** exige execução registrada com resultado, ambiente e evidência. Foram registrados CT01–CT10, com ressalva de que CT08 cobriu apenas aprovação Rx; consulte [testes](testes/README.md) e [evidências](evidencias/README.md). As capturas CT04 e CT06 não foram exportadas.

Não foram encontrados documentos do enunciado original, registros de sprints, diagramas anteriores ou suíte automatizada entre os arquivos do projeto. Os resultados recentes são evidências das execuções descritas nos registros, não dos demais casos planejados.



