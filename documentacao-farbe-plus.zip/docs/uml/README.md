# UML — modelos descritivos da versão inspecionada

Diagramas Mermaid derivados do código, sem ferramenta UML ou validação de execução. As classes abaixo são **entidades conceituais** dos objetos JavaScript; não são classes implementadas, tabelas ou serviços backend.

## Modelo conceitual

```mermaid
classDiagram
class Produto {
  id
  name
  category
  price
  stock
  emoji
  rx
  active
}
class ItemCarrinho {
  id
  qty
}
class Pedido {
  id
  customer
  shipping
  payment
  status
  rxStatus
  driver
  address
  date
}
class ItemPedido {
  id
  name
  price
  qty
  rx
}
Produto "1" <-- "0..1" ItemCarrinho : referencia por id
Pedido "1" *-- "1..*" ItemPedido : items
Produto "1" <-- "0..*" ItemPedido : id de origem
```

O pedido guarda nome e preço dos itens no momento da criação; o pedido inicial pode não conter o campo `rx`. Não há entidade de usuário autenticado; cliente e entregador são textos no pedido.

## Sequência da compra simulada com receita

```mermaid
sequenceDiagram
actor C as Cliente
participant A as App React
participant L as localStorage
actor F as Farmacêutico demonstrativo
C->>A: Adicionar produto Rx
C->>A: Informar endereço e marcar receita fictícia
C->>A: Confirmar pedido
A->>A: Validar carrinho, endereço e checkbox
A->>A: Criar pedido aguardando análise
A->>A: Baixar estoque e limpar carrinho
A->>L: Persistir estados por efeitos React
F->>A: Selecionar perfil e analisar pedido
alt Aprovar
A->>A: Receita aprovada, em preparação
else Rejeitar
A->>A: Receita rejeitada, cancelado
end
A->>L: Persistir pedidos
```

Os efeitos de persistência são independentes; o desenho não implica transação atômica. Os atores operam a mesma aplicação e armazenamento local.

## Casos de uso em texto

Cliente: consultar catálogo, gerenciar carrinho, finalizar simulação e consultar pedidos. Administrador: manter produtos/estoque e atualizar pedidos/entregadores. Farmacêutico: analisar receitas fictícias. Entregador Carlos: atualizar entregas atribuídas. A troca de ator é demonstrativa e não comprova controle de acesso.

## Estados e ressalvas

O código usa “Pedido realizado”, “Pagamento aprovado”, “Em preparação”, “Saiu para entrega” e “Entregue” na linha do tempo; também usa “Aguardando análise de receita”, “Cancelado” e “Tentativa sem sucesso”. O administrador pode selecionar estados sem uma máquina de estados completa. Um diagrama com sequência obrigatória de todas as transições não representaria fielmente a implementação.
