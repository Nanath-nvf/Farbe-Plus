# Evidências

## Evidência disponível

Revisão estática realizada em 17/11/2026: leitura de `src/main.jsx`, `src/style.css`, `package.json`, `package-lock.json`, `index.html` e README da raiz; inventário das pastas de documentação. Esses arquivos sustentam a descrição da implementação, não aprovação de testes funcionais.

As capturas e os registros dos cenários funcionais executados nesta sequência estão nos arquivos de saída ligados abaixo. Eles documentam somente os estados observados na aplicação demonstrativa.

## Registro para futuras evidências

| ID | Tipo | Situação |
| --- | --- | --- |
| EV01 | Inspeção estática do código e inventário | Realizada; conclusões nos documentos de requisitos e interfaces |
| EV02 | Saída do build | CT01 aprovado; saída e artefatos registrados em [CT01-registro.md](../../CT01-registro.md) |
| EV03 | Capturas do fluxo de compra e acompanhamento | CT05 registrada em [CT05-compra-simulada.png](../../CT05-compra-simulada.png) |
| EV04 | Capturas de análise Rx, administração e entrega | CT07/CT08/CT10 registradas; ver arquivos CT07, CT08 e CT10 em outputs |
| EV05 | Registro de testes de responsividade e acessibilidade | Pendente de execução |
| EV06 | Busca e ordenação do catálogo | CT02 registrada em [CT02-busca-paracetamol.png](../../CT02-busca-paracetamol.png) e [CT02-ordenacao-preco.png](../../CT02-ordenacao-preco.png) |
| EV07 | Detalhes, carrinho e endereço obrigatório | CT03: capturas em [CT03-produto-comum.png](../../CT03-produto-comum.png) e [CT03-produto-rx.png](../../CT03-produto-rx.png); CT04 e CT06: observações nos registros, sem captura exportada |

Para cada novo arquivo, registrar data, responsável, versão, ambiente, cenário de teste e resultado. Sugestão de nome: `CT05-compra-simulada-AAAA-MM-DD.png`. Use o ID real do teste, sem preencher datas ou resultados fictícios.

Capturas com dados iniciais, isoladamente, não demonstram persistência, segurança ou integração externa. Não anexar dados médicos, bancários ou pessoais reais.
`package-lock.json`: leitura retornou 35.634 bytes nulos e nenhum byte diferente de zero. Arquivo inválido para JSON; restauração/regeneração pendente. Nenhuma correção de dependências foi realizada.

Captura do catálogo após inativação: [CT09-produto-inativo.png](../../CT09-produto-inativo.png). Registros descritivos correspondentes estão em [CT05](../../CT05-registro.md), [CT07](../../CT07-registro.md), [CT08](../../CT08-registro.md), [CT09](../../CT09-registro.md) e [CT10](../../CT10-registro.md).



Registro complementar: [CT02 — catálogo, busca e ordenação](../../CT02-registro.md).


