# Protótipos

O frontend React em `src/main.jsx` e `src/style.css` é o protótipo executável encontrado. Ele demonstra fluxos de farmácia virtual com dados fictícios; não é um serviço comercial.

Não foram encontrados arquivos Figma, wireframes, mockups, imagens de telas ou versões anteriores no projeto inspecionado. Não há link de prototipação comprovado a registrar.

## Roteiro proposto de apresentação

1. Abrir início e catálogo, filtrar um produto e consultar seus detalhes.
2. Adicionar item ao carrinho e finalizar com endereço fictício.
3. Consultar o pedido e alternar para administrador para atribuir Carlos.
4. No perfil de entregador, registrar saída e entrega; retornar ao pedido.
5. Em outro pedido com Rx, marcar receita fictícia e demonstrar aprovação ou rejeição no perfil farmacêutico.

Este roteiro é uma proposta; não registra demonstração já executada. Consulte [interfaces](../interfaces/README.md) para inventário e [testes](../testes/README.md) para validação.

## Capturas a produzir

Início, catálogo, detalhe, carrinho, finalização, pedido, administração, análise de receita e entregador. Guardar imagens reais em `docs/evidencias/`, com identificação do cenário e sem dados pessoais reais. Não apresentar imagens ilustrativas como prova de execução.
