# Scrum — proposta de organização

Não foram encontrados registros de equipe, Product Owner, Scrum Master, sprints, reuniões, estimativas ou aceite. Este arquivo é uma proposta para organizar o trabalho; não representa histórico de Scrum executado.

## Backlog proposto

| Item | História | Referência | Situação documental |
| --- | --- | --- | --- |
| PB01 | Como cliente, quero localizar produtos para montar uma compra simulada | RF01–RF03 | Implementação identificada; validação pendente |
| PB02 | Como cliente, quero finalizar e consultar pedidos fictícios | RF04–RF06 | Implementação identificada; validação pendente |
| PB03 | Como apresentador, quero alternar perfis para demonstrar fluxos | RF07 | Implementação identificada; validação pendente |
| PB04 | Como administrador, quero manter catálogo, estoque e pedidos | RF08–RF09 | Implementação identificada; validação pendente |
| PB05 | Como farmacêutico/entregador, quero demonstrar análise e entrega | RF10 | Implementação identificada; validação pendente |
| PB06 | Como equipe, quero tratar inconsistências de estoque e status | Limitações em requisitos | Melhoria proposta, não realizada |
| PB07 | Como avaliador, quero documentação e evidências verificáveis | RNF04–RNF05, testes | Documentação preparada; execução e aceite pendentes |

## Próximo ciclo sugerido

Priorizar execução dos testes, registrar falhas e evidências, revisar requisitos com o enunciado e então selecionar correções. Responsáveis, datas e capacidade devem ser definidos pela equipe; não há estimativas aprovadas.

## Modelo de registro de sprint

Preencher com dados reais: identificação e período; participantes e papéis; objetivo; itens selecionados; tarefas e responsáveis; impedimentos; resultados da revisão; retrospectiva; evidências de aceite.

## Critério de conclusão proposto

Requisito revisado, comportamento demonstrado, teste com resultado registrado, evidência vinculada e limitações atualizadas. Leitura de código isolada não atende a esse critério.
