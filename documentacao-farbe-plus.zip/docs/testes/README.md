# Plano e registro de testes

## Resultado desta revisão — 17/11/2026

A inspeção estática identificou os fluxos e limitações descritos em requisitos. Foram executados CT01–CT10, exceto que CT08 cobriu apenas aprovação Rx; a rejeição prevista segue pendente. CT03, CT04 e CT06 foram executados em 17/11/2026 na cópia local de demonstração aberta em Microsoft Edge (`http://localhost:5180/`). O manifesto não define script `test` e não foi encontrada suíte automatizada. Isso não comprova ausência de testes feitos anteriormente fora da pasta.

## Preparação para execução

Usar navegador e dados exclusivamente de teste. Registrar sistema, navegador/versão, data, responsável e versão do projeto. Para cenários independentes, usar uma origem/perfil de teste limpo; a limpeza do armazenamento apaga dados locais. Registrar também erros do console e resultado do build.

## Casos planejados

Os resultados esperados são critérios a verificar, não resultados obtidos. Situação atual: CT01–CT10 executados, com a ressalva de que CT08 cobriu somente aprovação; CT11–CT16 ainda não executados.

| ID | Requisito | Procedimento | Resultado esperado / ponto a observar |
| --- | --- | --- | --- |
| CT01 | RNF05 | Executar `npm run build` | Build termina sem erro e gera `dist/` |
| CT02 | RF01 | Em estado inicial limpo, abrir catálogo, buscar Paracetamol e ordenar preços | 20 produtos ativos iniciais; filtro por nome e ordenação coerentes |
| CT03 | RF02 | Abrir produto comum e produto Rx | Nome, categoria, preço, estoque e aviso Rx correspondem ao catálogo |
| CT04 | RF03 | Adicionar, aumentar até limite, reduzir, remover e esvaziar | Quantidade não excede estoque na adição; totais e remoção coerentes |
| CT05 | RF04 | Comprar 1 Paracetamol de R$ 18,50, sem Rx | Total R$ 26,40; pedido em preparação; estoque reduz uma unidade e carrinho esvazia |
| CT06 | RF04 | Tentar confirmar com endereço em branco | Pedido não criado; mensagem solicita endereço |
| CT07 | RF05 | Comprar item Rx sem checkbox; depois marcar e confirmar | Primeiro bloqueia; depois cria pedido aguardando análise |
| CT08 | RF10 | Aprovar um pedido Rx e rejeitar outro | Aprovação prepara; rejeição cancela; registrar que estoque não é reposto pela implementação atual |
| CT09 | RF08 | Cadastrar/editar/inativar produto e ajustar estoque | Alterações aparecem nas telas; produto inativo sai do catálogo |
| CT10 | RF09–RF10 | Atribuir pedido comum a Carlos; sair para entrega e concluir | Painel de Carlos exibe pedido; cliente vê atualização |
| CT11 | RNF01 | Alterar carrinho/produtos/pedidos e recarregar mesma origem | Dados persistem; perfil e tela voltam ao estado inicial |
| CT12 | RNF02–RNF04 | Usar telas em 1280, 640 e 375 px e navegar por teclado | Registrar legibilidade, foco, alcance dos controles e problemas encontrados |
| CT13 | RF03–RF04 | Adicionar item, reduzir estoque no admin e confirmar compra | Verificar prevenção de estoque negativo; inspeção indica ausência de revalidação na confirmação |
| CT14 | RF09–RF10 | Atribuir a Fernanda; testar pedido cancelado atribuído a Carlos | Registrar limitações: painel fixo em Carlos e possível saída de pedido cancelado |
| CT15 | RF06 | Consultar pedido cancelado ou com tentativa sem sucesso | Comparar status textual e linha do tempo; registrar divergência se houver |
| CT16 | RF08 | Tentar salvar produto sem nome, preço/estoque negativo ou estoque fracionário | Nome vazio e negativos devem ser recusados; validar comportamento para estoque não inteiro |

## Modelo de registro por execução

Registrar: ID; data/hora; responsável; versão do projeto; ambiente; pré-condições e dados; passos; resultado observado; situação (aprovado/reprovado/bloqueado); caminho da evidência; defeito associado. Não substituir o resultado observado pelo resultado esperado.

## Registros de execução

- [CT03 — detalhes dos produtos](../../CT03-registro.md)
- [CT04 — carrinho e limite de estoque](../../CT04-registro.md)
- [CT06 — endereço obrigatório](../../CT06-registro.md)
- [CT05 — compra simulada](../../CT05-registro.md)
- [CT07 — fluxo de receita fictícia](../../CT07-registro.md)
- [CT08 — aprovação Rx](../../CT08-registro.md)
- [CT09 — produto e estoque](../../CT09-registro.md)
- [CT10 — fluxo de entrega](../../CT10-registro.md)


- [CT01 — build](../../CT01-registro.md)


- [CT02 — catálogo, busca e ordenação](../../CT02-registro.md)

