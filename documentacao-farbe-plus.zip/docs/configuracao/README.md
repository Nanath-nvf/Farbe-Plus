# Configuração e execução

## Estrutura identificada

- `src/main.jsx`: dados iniciais, estado React, telas e regras demonstrativas.
- `src/style.css`: estilos e adaptação de layout.
- `index.html`: entrada da aplicação.
- `package.json` e `package-lock.json`: scripts e dependências.
- `docs/`: documentação acadêmica.

Aplicação frontend sem API, servidor de negócio, banco remoto ou arquivo de variáveis de ambiente identificado.

## Dependências declaradas

React e React DOM `^19.0.0`, Vite `^6.1.0`, lucide-react `^0.468.0`. Estes são intervalos do manifesto, não uma afirmação das versões instaladas. O `package-lock.json` lido tem 35.634 bytes, todos nulos: não contém JSON válido e não permite confirmar versões resolvidas. É necessário restaurá-lo de uma cópia válida ou regenerá-lo antes de confiar em uma instalação reproduzível. Não foi identificada versão de Node fixada pelo projeto.

## Executar no Windows / VS Code

No terminal do VS Code, a partir da raiz do projeto:

```powershell
Set-Location 'E:\Downloads\farbe-plus'
npm install
npm run dev
```

Pré-requisito: Node.js e npm compatíveis com as dependências. Antes de instalar, restaure um lockfile válido do histórico ou preserve uma cópia do arquivo atual e regenere-o com npm. O comando acima pressupõe essa correção; esta revisão não alterou dependências. Não é necessário instalar novamente a cada execução. Abra o endereço informado pelo Vite e encerre com Ctrl+C. O script atual usa `--host 0.0.0.0`, portanto pode disponibilizar o servidor à rede conforme a configuração do computador. Para demonstração somente local: `npm run dev -- --host 127.0.0.1`.

Para gerar e conferir a versão estática:

```powershell
npm run build
npm run preview -- --host 127.0.0.1
```

O build padrão gera `dist/`. Esta revisão não afirma sucesso desses comandos: consultar o registro de testes.

## Dados locais

As chaves `farbe_products`, `farbe_orders` e `farbe_cart` persistem no navegador e na origem usada. Perfil e tela não são persistidos. Outro navegador, porta ou dispositivo pode apresentar dados diferentes. Limpar essas três chaves nas ferramentas do navegador restaura os exemplos na próxima carga e apaga alterações demonstrativas; faça isso apenas em ambiente de teste, preservando qualquer evidência necessária.

Use somente informações fictícias. Não insira receitas, endereços, dados bancários ou dados médicos reais.

## Proposta de gestão de configuração — Etapa 3

Esta seção é uma proposta para organizar a evolução futura do Farbe+. Ela não significa que o repositório remoto, as regras de proteção ou as permissões abaixo já estejam configuradas.

### Organização do repositório

Manter o código-fonte, a documentação e os arquivos de apoio do mesmo projeto em um repositório GitHub, com esta estrutura de referência:

```text
farbe-plus/
├── docs/
│   ├── configuracao/
│   ├── evidencias/
│   ├── interfaces/
│   ├── prototipos/
│   ├── requisitos/
│   ├── scrum/
│   ├── testes/
│   └── uml/
├── src/
├── index.html
├── package.json
├── package-lock.json
└── README.md
```

Arquivos gerados localmente, como `node_modules/` e `dist/`, não devem ser versionados. O `package-lock.json` precisa ser válido e acompanhar alterações de dependências para permitir instalações reproduzíveis. Antes de publicar, conferir o arquivo atual: a inspeção desta cópia encontrou um lockfile inválido.

### Versionamento e mudanças

- Usar `main` para a versão estável apresentada na entrega.
- Fazer mudanças em branches curtas, por exemplo `docs/etapa-3` ou `feat/catalogo`, e integrá-las após revisão.
- Escrever commits objetivos, identificando o tipo de mudança, como `docs: registrar requisitos` ou `fix: validar endereço`.
- Criar tags de versão para entregas importantes, por exemplo `v1.0.0`, e registrar mudanças relevantes no README ou em um histórico de versões.
- Em mudanças de código, conferir build e cenários relacionados antes de integrar; manter resultados planejados claramente separados dos testes executados.

### Acesso, segurança e cópias

- Manter o repositório privado durante o desenvolvimento e conceder acesso apenas à equipe e ao professor indicado na atividade; confirmar o usuário antes de convidá-lo.
- Nunca incluir senhas, tokens, receitas ou dados pessoais/reais nos commits, arquivos de configuração ou evidências.
- Usar o histórico remoto do GitHub como cópia versionada e manter uma cópia local do projeto. Evitar substituir arquivos sem revisar o diff.
- Registrar no README o objetivo do projeto, como executar a aplicação, a estrutura de pastas e o link do repositório quando ele existir.

### Situação desta proposta

Os itens acima descrevem uma organização sugerida. A criação do repositório no GitHub, o envio do projeto e a concessão de acesso ao professor precisam ser realizados e confirmados separadamente; não são comprovados por esta documentação local.
