# Interfaces

Inventário derivado de `src/main.jsx` e `src/style.css`, sem validação visual nesta revisão. As telas são selecionadas pelo estado `page`; não há roteador com URLs próprias.

| Tela (`page`) | Elementos e ações principais |
| --- | --- |
| Início (`home`) | Destaques, categorias, catálogo e acesso aos perfis |
| Catálogo (`catalog`) | Busca por nome, categoria, ordenação e produtos ativos |
| Produto (`product`) | Detalhes e inclusão no carrinho |
| Carrinho (`cart`) | Quantidades, remoção, subtotal, frete e checkout |
| Finalização (`checkout`) | Endereço fictício, forma de pagamento e checkbox de receita quando necessário |
| Pedidos (`orders`) | Histórico demonstrativo e acesso aos detalhes |
| Pedido (`order`) | Linha do tempo, itens, total e entrega |
| Perfis (`profiles`) | Seleção de cliente, administrador, farmacêutico e entregador |
| Administração (`admin`) | Visão geral, Pedidos, Produtos, Estoque e Entregas; modal de produto |
| Farmacêutico (`farmaceutico`) | Fila de receitas fictícias, aprovação, rejeição e histórico |
| Entregador (`entregador`) | Pedidos de Carlos e ações de atualização |

Cabeçalho e rodapé são compartilhados. Identidade: azul e branco, fonte Inter com fallback Arial, ícones lucide-react e emojis nos produtos. A fonte Inter depende de Google Fonts; não há comprovação de carregamento offline.

## Fluxos de navegação

1. Início → catálogo → produto/carrinho → finalização → acompanhamento.
2. Perfis → administrador → produtos/estoque/pedidos/entregas.
3. Pedido Rx → perfis → farmacêutico → aprovar ou rejeitar → conferir pedido.
4. Administrador atribui Carlos → entregador → saída/entrega → cliente consulta pedido.

## Validação pendente

Conferir as telas em desktop e celular, foco de teclado, rótulos dos botões de ícone, contraste, mensagens e estados vazios. Não há capturas de tela anexadas como evidência. Ver [roteiro de testes](../testes/README.md).
