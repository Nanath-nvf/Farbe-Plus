# Requisitos do sistema — Farbe+

## Objetivo e escopo

Demonstrar catálogo, compra simulada, análise fictícia de receitas e acompanhamento de entregas em um projeto acadêmico. Requisitos abaixo foram reconstruídos a partir de `src/main.jsx`; precisam ser confrontados com o enunciado da disciplina. Nenhuma transação real é realizada.

## Atores demonstrativos

| Ator | Identidade de exemplo | Responsabilidade representada |
| --- | --- | --- |
| Cliente | Ana | Consultar produtos, montar carrinho e acompanhar pedidos |
| Administrador | Roberto | Gerenciar produtos, estoque, pedidos e entregadores |
| Farmacêutico | Dra. Marina | Aprovar ou rejeitar receitas fictícias |
| Entregador | Carlos | Atualizar entregas atribuídas a Carlos |

A seleção de perfil não autentica usuários e não restringe acesso com segurança. Fernanda aparece como opção de atribuição administrativa, mas o painel de entregador filtra apenas Carlos.

## Requisitos funcionais

Todos os itens RF01–RF10 estão **identificados no código, sem teste funcional executado nesta revisão**.

| ID | Requisito e critério de aceite proposto | Evidência de implementação |
| --- | --- | --- |
| RF01 | Listar produtos ativos; filtrar por categoria e trecho do nome; ordenar por nome ou preço | `visible`, tela `catalog` |
| RF02 | Mostrar nome, categoria, preço, estoque e indicação de receita nos detalhes | tela `product` |
| RF03 | Adicionar, alterar quantidades, remover e esvaziar carrinho; limitar adição ao estoque disponível | `add`, `change`, tela `cart` |
| RF04 | Criar pedido com endereço não vazio, Pix/Cartão/Boleto simulados e frete fixo de R$ 7,90; baixar estoque e limpar carrinho | `placeOrder`, tela `checkout` |
| RF05 | Exigir marcação de receita fictícia para item Rx e encaminhar pedido à análise | `needsRx`, `checkout.rx`, `rxStatus` |
| RF06 | Exibir histórico, itens, total, endereço, entregador e status do pedido | telas `orders` e `order` |
| RF07 | Alternar entre quatro perfis de demonstração | `roles`, `chooseRole`, tela `profiles` |
| RF08 | Cadastrar/editar produtos, ativar/inativar e ajustar estoque; exibir indicadores administrativos | tela `admin`, `editing`, `setProducts` |
| RF09 | Filtrar pedidos, atualizar status e atribuir Carlos ou Fernanda; bloquear seletor de status enquanto receita aguarda análise | `adminTab`, `updateOrder` |
| RF10 | Aprovar/rejeitar receita fictícia; registrar saída, entrega ou tentativa sem sucesso no painel de Carlos | telas `farmaceutico` e `entregador` |

## Requisitos não funcionais

| ID | Requisito | Situação e limite |
| --- | --- | --- |
| RNF01 | Persistir catálogo, pedidos e carrinho entre recargas no mesmo navegador/origem | Identificado: chaves `farbe_products`, `farbe_orders`, `farbe_cart` em `localStorage`; sem teste executado |
| RNF02 | Adaptar layout a telas menores | Identificado: media queries em 900, 640 e 380 px; validação visual pendente |
| RNF03 | Comunicar caráter acadêmico e simulado | Identificado no rodapé, checkout e seleção de perfis; sem auditoria de compreensão |
| RNF04 | Permitir uso por teclado e tecnologias assistivas | Planejado/proposto: realizar avaliação de acessibilidade; conformidade não demonstrada |
| RNF05 | Documentar execução e geração de versão estática | Scripts `dev`, `build` e `preview` existentes; execução e compatibilidade ainda precisam de registro |

## Regras e limitações observadas

- A busca compara apenas o nome, apesar do campo mencionar marca ou sintoma. “Ofertas do dia” apenas ordena por menor preço.
- Há 20 produtos e um pedido iniciais quando não existe armazenamento anterior.
- Pedido comum inicia em “Em preparação”; pedido Rx, em “Aguardando análise de receita”. Aprovação leva a “Em preparação”; rejeição, a “Cancelado”.
- A linha do tempo mostra cinco etapas fixas; não representa adequadamente todos os estados alternativos, como cancelamento e tentativa sem sucesso.
- Cancelamento/rejeição não possuem reposição automática de estoque no código inspecionado.
- A finalização não revalida estoque e produto ativo imediatamente antes da baixa. Alterações administrativas posteriores à adição ao carrinho exigem teste.
- O botão de saída do entregador não bloqueia explicitamente pedidos cancelados. A atribuição não constitui autorização segura.
- Não existem cadastro/login reais, upload de receita, análise clínica, cobrança, rastreamento por GPS, API ou banco de dados remoto no projeto lido.

## Evoluções propostas, fora da implementação comprovada

Validar estoque na confirmação, tratar transições de status e reposição no cancelamento, completar painel de Fernanda, aprimorar acessibilidade e testes. Backend, autenticação e integrações reais dependeriam de novo escopo e revisão adequada antes de qualquer uso real.
