# Registro de execução — requisito de receita fictícia (CT07)

Data: 17/11/2026. Execução no Microsoft Edge em `http://127.0.0.1:5180/`; versão exata do navegador e commit não coletados. Dados de endereço, produto e receita eram fictícios do próprio protótipo.

## Passos e resultados observados

1. Buscou `Medicamento Exemplo Rx`: um produto encontrado, identificado com receita fictícia necessária e preço de R$ 42,90.
2. Adicionou uma unidade ao carrinho. Total com frete exibido: R$ 50,80.
3. No checkout, deixou desmarcada a opção de receita fictícia e tentou confirmar. A aplicação exibiu “Selecione a receita fictícia para os produtos sinalizados.” e permaneceu no checkout; nenhum pedido foi criado nessa tentativa.
4. Marcou a opção fictícia e confirmou. O pedido FB-1003 foi criado com status “Aguardando análise de receita”, receita “Aguardando”, uma unidade do produto e total de R$ 50,80. O carrinho ficou vazio.

## Conclusão

CT07 aprovado para este cenário. O teste confirma a validação da opção fictícia e a criação do pedido aguardando análise. Não avalia análise farmacêutica real, upload de receita, segurança, persistência após recarga nem resultado de aprovação/rejeição.

Evidência da tela do pedido: [CT07-pedido-rx.png](CT07-pedido-rx.png). A mensagem de bloqueio foi observada na interface durante a tentativa inicial.