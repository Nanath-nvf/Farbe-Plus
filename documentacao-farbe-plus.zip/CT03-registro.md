# CT03 — Detalhes de produtos

- **Data:** 17/11/2026
- **Ambiente:** cópia local demonstrativa em `http://localhost:5180/`, Microsoft Edge; perfil Ana; dados fictícios.
- **Passos:** abrir os detalhes de um produto comum e de um produto Rx.
- **Resultado observado:** Paracetamol 750mg exibiu categoria Medicamentos, preço R$ 18,50 e estoque 24. “Medicamento Exemplo Rx” exibiu categoria Medicamentos, preço R$ 42,90, estoque 10 e o aviso “Exige receita fictícia de demonstração”. Os dados da tela corresponderam aos produtos inspecionados.
- **Situação:** aprovado para os itens verificados.
- **Evidências:** [produto comum](CT03-produto-comum.png) e [produto Rx](CT03-produto-rx.png).
- **Limite:** dados e receita são demonstrações; o cenário não valida informação farmacêutica real.
