# CT06 — Endereço obrigatório

- **Data:** 17/11/2026
- **Ambiente:** cópia local demonstrativa em `http://localhost:5180/`, Microsoft Edge; perfil Ana; dados fictícios.
- **Passos:** adicionar uma unidade de Paracetamol 750mg, abrir Finalizar compra, limpar o endereço demonstrativo e tentar confirmar o pedido simulado.
- **Resultado observado:** a tela manteve o checkout e exibiu “Informe um endereço demonstrativo.”. O endereço permaneceu em branco e o carrinho continuou com uma unidade; a tela de confirmação do pedido não foi aberta.
- **Situação:** aprovado para o bloqueio de confirmação sem endereço.
- **Evidência:** estado observado diretamente na interface durante a execução; a captura de tela deste cenário não foi exportada como arquivo.
- **Limite:** valida somente o fluxo local simulado; não foi realizada compra nem transmissão de dados.
