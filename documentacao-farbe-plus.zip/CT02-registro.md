# Registro de execução — catálogo, busca e ordenação (CT02)

Data: 17/11/2026. Execução no Microsoft Edge em `http://localhost:5180/`, usando origem limpa para não alterar os dados dos cenários anteriores. Perfil demonstrativo Ana (cliente). Versão exata do navegador e commit não coletados.

## Procedimento e resultado

Abriu o catálogo na origem limpa. A tela mostrou 20 produtos encontrados e a lista inicial de produtos. Pesquisou “Paracetamol”; a busca retornou 1 produto, Paracetamol 750mg, por R$ 18,50, com 24 unidades em estoque. Limpou a busca e selecionou “Menor preço”. A lista de 20 produtos foi reorganizada em ordem crescente: Algodão Hidrófilo (R$ 8,90), Curativo Adesivo (R$ 9,90), Escova Dental (R$ 11,90), Soro Fisiológico (R$ 12,90), entre os primeiros resultados, e os preços maiores ao final.

## Conclusão e limite

A contagem inicial, a busca por nome e a ordenação crescente por preço foram aprovadas neste cenário demonstrativo. Não foi verificada a opção “Maior preço”. A origem `localhost:5180` manteve o armazenamento de teste separado da origem `127.0.0.1:5180` usada nos cenários anteriores.

Evidências: [busca por Paracetamol](CT02-busca-paracetamol.png) e [catálogo ordenado por menor preço](CT02-ordenacao-preco.png).
