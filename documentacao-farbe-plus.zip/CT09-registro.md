# Registro de execução — cadastro, edição, estoque e inativação (CT09)

Data: 17/11/2026. Execução no Microsoft Edge em `http://127.0.0.1:5180/`, com perfil demonstrativo Roberto (administrador). Versão exata do navegador e commit não coletados.

## Procedimento e resultado

Cadastrou “Produto Teste CT09” na categoria Medicamentos com preço R$ 10,00 e estoque 5. Editou o produto para preço R$ 12,00 e estoque 8; o painel de produtos refletiu os novos valores. Em seguida, desmarcou “Produto ativo” e salvou. O painel administrativo identificou o produto como “Inativo”. Pesquisou o nome no catálogo e a tela mostrou “0 produtos encontrados” e “Nenhum produto encontrado”.

## Conclusão e limite

O cadastro, a edição de preço e estoque e a retirada do catálogo após inativação foram aprovados neste cenário demonstrativo. O produto de teste permanece salvo como inativo no armazenamento local do navegador para preservar o resultado verificável.

Evidência: [busca no catálogo sem resultados para o produto inativo](CT09-produto-inativo.png).
