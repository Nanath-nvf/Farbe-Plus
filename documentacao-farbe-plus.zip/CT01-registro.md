# Registro de execução — build (CT01)

Data: 17/11/2026. Projeto: cópia de validação em `outputs/farbe-plus-validacao`. Comando: `npm run build`.

## Resultado observado

Build aprovado. O Vite 6.4.6 transformou 1.573 módulos e concluiu em 2,53 s, gerando `dist/index.html`, `dist/assets/index-BpS9xA4A.css` e `dist/assets/index-CzQJE6HI.js`.

As dependências já estavam disponíveis em `node_modules`; não foi feita instalação ou atualização. O resultado vale para esta cópia de validação e seu ambiente atual.
